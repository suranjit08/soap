package com.util;
import java.util.UUID;

public class Util {

    public static String getRandomId(){

        return UUID.randomUUID().toString();
    }
}

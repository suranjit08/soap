package com.model;

import java.io.Serializable;

public class ResponseBean implements Serializable {
    private String responseCode="";
    //private String schema="";
    private String type="";
    private String description="";
    private String defaultVal="";
    private String simpleRef;
    private String genericRef;
    public ResponseBean(String responseCode){
        this.responseCode=responseCode;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDefaultVal() {
        return defaultVal;
    }

    public void setDefaultVal(String defaultVal) {
        this.defaultVal = defaultVal;
    }

    public String getSimpleRef() {
        return simpleRef;
    }

    public void setSimpleRef(String simpleRef) {
        this.simpleRef = simpleRef;
    }

    public String getGenericRef() {
        return genericRef;
    }

    public void setGenericRef(String genericRef) {
        this.genericRef = genericRef;
    }
}

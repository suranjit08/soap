package com.model;

import io.swagger.models.HttpMethod;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class SoapRestActionModel implements Serializable {

    private String slNo;
    private String mockName;
    private String method;
    private String resourcePath;
    private String mockId;
    private String defaultResponde;
    private String dispatchStyle;
    private String responseName;
    private String responseId;
    private String httpStatusCode;
    private String mediaType="";
    private String operationId;
    private Map<String,String> headerDetails= new HashMap<String,String>();
    private Map<String,String> mockMapRefResponses= new HashMap<String,String>();
    private Map<String,ParameterBean> parameters= new HashMap<String,ParameterBean>();
    private Map<String,ResponseBean> mockMapStatusRefResponses= new HashMap<String,ResponseBean>();


    public String getSlNo() {
        return slNo;
    }

    public void setSlNo(String slNo) {
        this.slNo = slNo;
    }

    public String getMockName() {
        return mockName;
    }

    public void setMockName(String mockName) {
        this.mockName = mockName;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getResourcePath() {
        return resourcePath;
    }

    public void setResourcePath(String resourcePath) {
        this.resourcePath = resourcePath;
    }

    public String getMockId() {
        return mockId;
    }

    public void setMockId(String mockId) {
        this.mockId = mockId;
    }

    public String getDefaultResponde() {
        return defaultResponde;
    }

    public void setDefaultResponde(String defaultResponde) {
        this.defaultResponde = defaultResponde;
    }

    public String getDispatchStyle() {
        return dispatchStyle;
    }

    public void setDispatchStyle(String dispatchStyle) {
        this.dispatchStyle = dispatchStyle;
    }

    public String getResponseName() {
        return responseName;
    }

    public void setResponseName(String responseName) {
        this.responseName = responseName;
    }

    public String getResponseId() {
        return responseId;
    }

    public void setResponseId(String responseId) {
        this.responseId = responseId;
    }

    public String getHttpStatusCode() {
        return httpStatusCode;
    }

    public void setHttpStatusCode(String httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    public String getMediaType() {
        return mediaType;
    }

    public void setMediaType(String mediaType) {
        this.mediaType = mediaType;
    }

    public String getOperationId() {
        return operationId;
    }

    public void setOperationId(String operationId) {
        this.operationId = operationId;
    }

    public Map<String, String> getHeaderDetails() {
        return headerDetails;
    }

    public void setHeaderDetails(Map<String, String> headerDetails) {
        this.headerDetails = headerDetails;
    }

    public Map<String, ParameterBean> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, ParameterBean> parameters) {
        this.parameters = parameters;
    }

    public Map<String, ResponseBean> getMockMapStatusRefResponses() {
        return mockMapStatusRefResponses;
    }

    public void setMockMapStatusRefResponses(Map<String, ResponseBean> mockMapStatusRefResponses) {
        this.mockMapStatusRefResponses = mockMapStatusRefResponses;
    }

    public Map<String, String> getMockMapRefResponses() {
        return mockMapRefResponses;
    }

    public void setMockMapRefResponses(Map<String, String> mockMapRefResponses) {
        this.mockMapRefResponses = mockMapRefResponses;
    }
}

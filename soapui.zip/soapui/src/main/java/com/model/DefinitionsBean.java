package com.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DefinitionsBean implements Serializable {
    private String responseName;
    private String type;
    private List<PropertiesBean> listProperties=new ArrayList<PropertiesBean>();
    private String xmlName;
    private String response;
    public DefinitionsBean(String responseName){
        this.responseName=responseName;
    }

    public String getResponseName() {
        return responseName;
    }

    public void setResponseName(String responseName) {
        this.responseName = responseName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<PropertiesBean> getListProperties() {
        return listProperties;
    }

    public void setListProperties(List<PropertiesBean> listProperties) {
        this.listProperties = listProperties;
    }

    public String getXmlName() {
        return xmlName;
    }

    public void setXmlName(String xmlName) {
        this.xmlName = xmlName;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }
}

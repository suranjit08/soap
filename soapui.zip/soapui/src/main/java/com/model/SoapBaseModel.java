package com.model;

import io.swagger.models.Swagger;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SoapBaseModel implements Serializable {
    private String projectName;
    private String projectId;
    private String port;
    private String mockServiceId;
    private String mockServiceName;
    private String hostName;
    private Swagger swagger;
    private List<SoapRestActionModel> actionList=new ArrayList();
    private Map<String,DefinitionsBean> mapDefinitionsBean= new HashMap<String,DefinitionsBean>();

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getMockServiceId() {
        return mockServiceId;
    }

    public void setMockServiceId(String mockServiceId) {
        this.mockServiceId = mockServiceId;
    }

    public String getMockServiceName() {
        return mockServiceName;
    }

    public void setMockServiceName(String mockServiceName) {
        this.mockServiceName = mockServiceName;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public List<SoapRestActionModel> getActionList() {
        return actionList;
    }

    public void setActionList(List<SoapRestActionModel> actionList) {
        this.actionList = actionList;
    }

    public Swagger getSwagger() {
        return swagger;
    }

    public void setSwagger(Swagger swagger) {
        this.swagger = swagger;
    }

    public Map<String, DefinitionsBean> getMapDefinitionsBean() {
        return mapDefinitionsBean;
    }

    public void setMapDefinitionsBean(Map<String, DefinitionsBean> mapDefinitionsBean) {
        this.mapDefinitionsBean = mapDefinitionsBean;
    }
}

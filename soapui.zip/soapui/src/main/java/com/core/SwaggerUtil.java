package com.core;

import com.model.*;
import com.util.Util;
import io.swagger.models.*;
import io.swagger.models.parameters.BodyParameter;
import io.swagger.models.parameters.Parameter;
import io.swagger.models.parameters.QueryParameter;
import io.swagger.models.properties.ArrayProperty;
import io.swagger.models.properties.Property;
import io.swagger.models.properties.RefProperty;
import io.swagger.parser.SwaggerParser;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;


public class SwaggerUtil {

    public static String file_path = "C:\\Users\\Suranjit\\IdeaProjects\\soapui\\src\\main\\resources\\swagger\\1.yaml";

    public static SoapBaseModel getSwaggerSoapApiModel() {
        SwaggerParser swaggerParser = new SwaggerParser();
        int slNo = 0;
        String content = "";
        try {
            content = new String(Files.readAllBytes(Paths.get(file_path)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        Swagger swagger = swaggerParser.parse(content);
        SoapBaseModel soapBaseModel = new SoapBaseModel();
        soapBaseModel.setProjectName("Demo mock service");
        soapBaseModel.setProjectId(Util.getRandomId());
        soapBaseModel.setPort("8080");
        soapBaseModel.setMockServiceId(Util.getRandomId());
        soapBaseModel.setMockServiceName("demo service");
        List<SoapRestActionModel> actionList = soapBaseModel.getActionList();
        Map<String, Path> paths = swagger.getPaths();
        for (Map.Entry<String, Path> p : paths.entrySet()) {
            Path path = p.getValue();
            Map<HttpMethod, Operation> operations = path.getOperationMap();
            for (Map.Entry<HttpMethod, Operation> o : operations.entrySet()) {
                System.out.println("Path" + p.getKey());
                SoapRestActionModel soapRestActionModel = new SoapRestActionModel();
                soapRestActionModel.setSlNo(String.valueOf(++slNo));
                soapRestActionModel.setMockId(Util.getRandomId());
                soapRestActionModel.setMockName(p.getKey());
                soapRestActionModel.setOperationId(o.getValue().getOperationId());
                soapRestActionModel.setMethod((o.getKey().toString()).toUpperCase());
                soapRestActionModel.setResourcePath(p.getKey());
                Map<String, ParameterBean> parameters = soapRestActionModel.getParameters();
                for (Parameter parameter : o.getValue().getParameters()) {
                    String parameterName = parameter.getName();
                    ParameterBean parameterBean = new ParameterBean();
                    setParameter(parameter, parameterBean);
                    parameters.put(parameterName, parameterBean);
                }

                Map<String, ResponseBean> mockMapStatusRefResponses = soapRestActionModel.getMockMapStatusRefResponses();
                for (Map.Entry<String, Response> r : o.getValue().getResponses().entrySet()) {
                    System.out.println("Get Response" + r.getKey() + "--" + r.getValue().getDescription());
                    ResponseBean responseBean = new ResponseBean(r.getKey());
                    setResponse(r.getValue(), responseBean);
                    mockMapStatusRefResponses.put(r.getKey(), responseBean);
                    System.out.println("After Setting Response");
                    //mockMapStatusRefResponses.put(r.getKey(), r.getValue().getDescription());//400,Invalid Id
                    //mockMapStatusRefResponses.put(r.getKey(),((RefProperty)r.getValue().getSchema()).getSimpleRef());
                }

                actionList.add(soapRestActionModel);
            }

        }
        Map<String, Model> definitions = swagger.getDefinitions();
        for (Map.Entry<String, Model> m : definitions.entrySet()) {
            System.out.println("In Model");
            DefinitionsBean definitionsBean = new DefinitionsBean(m.getKey());
            setDefination(m.getValue(), definitionsBean);
            soapBaseModel.getMapDefinitionsBean().put(m.getKey(), definitionsBean);
        }
        return soapBaseModel;
    }

    public static void setDefination(Model model, DefinitionsBean definitionsBean) {
        System.out.println("In def Bean");
        try {
            definitionsBean.setType((((ModelImpl) model).getType());
        } catch (Exception e) {

        }
        try {
            definitionsBean.setXmlName((ModelImpl) model).getXml().getName());
        }
         catch(Exception e){

        }
        for (Property m : model.getProperties()) {
            System.out.println("In Model");
            //DefinitionsBean definitionsBean = new DefinitionsBean(m.getKey());
         //   setDefination(m.getValue(), definitionsBean);
          //  soapBaseModel.getMapDefinitionsBean().put(m.getKey(), definitionsBean);
        }
    }

    public static void setParameter(Parameter parameter, ParameterBean parameterBean) {
        String parameterType = "";
        System.out.println("Parameter Name");
        try {
            parameterBean.setName(parameter.getName());
            parameterBean.setType(((QueryParameter) parameter).getType());
        } catch (Exception e) {

        }
        try {

            parameterBean.setSchema((((BodyParameter) parameter).getSchema().getReference()));

        } catch (Exception e) {

        }
        try {
            parameterBean.setIn(parameter.getIn());
        } catch (Exception e) {

        }
        try {
            parameterBean.setRequired(String.valueOf(parameter.getRequired()));
        } catch (Exception e) {

        }
        try {
            parameterBean.setDescription(parameter.getDescription());
        } catch (Exception e) {

        }

    }

    public static void setResponse(Response response, ResponseBean responseBean) {

        try {
            responseBean.setDescription(response.getDescription());
        } catch (Exception e) {

        }
        try {

            responseBean.setType(response.getSchema().getType());
        } catch (Exception e) {

        }
        try {
            responseBean.setGenericRef((((RefProperty) ((ArrayProperty) response.getSchema()).getItems()).get$ref()));
            responseBean.setSimpleRef((((RefProperty) ((ArrayProperty) response.getSchema()).getItems()).getSimpleRef()));

        } catch (Exception e) {

        }

    }

}


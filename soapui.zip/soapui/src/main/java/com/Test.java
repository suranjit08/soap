package com;

import com.core.SwaggerUtil;
import com.model.SoapBaseModel;

public class Test {
    public static  void main(String[] args){
        System.out.println("Hi this is test");
        SoapBaseModel soapBaseModel=SwaggerUtil.getSwaggerSoapApiModel();
        System.out.println("Test Project"+soapBaseModel);
    }
}
